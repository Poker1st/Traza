exports.run = (client, message, [mention, ...reason]) => {
  const ms = require("ms");
  let member = message.mentions.members.first();
  if (!member) return message.reply("you didn't specify a member");
  let muteRole = message.guild.roles.find('name', "Muted");
  let params = message.content.split(" ").slice(1);
  let time = params[1];
  if (!muteRole) return message.reply("there is no Muted Role, please create a role and call it Muted.")
  if(!time) return message.reply("You need to specify a time");

  member.addRole(muteRole)
  message.channel.send(`${member.user.tag} has been muted for: ${ms(ms(time), {long: true})}`);

  setTimeout(function() {
    member.removeRole(muteRole);
    message.channel.send(`${member.user.tag} is now unmuted!`)
  }, ms(time));
}
