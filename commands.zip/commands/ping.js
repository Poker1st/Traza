exports.run = (client, message, args) => {
  message.channel.send('Pong...').then((message) => {
    message.edit(`Pong! Latency is ${message.createdTimestamp - message.createdTimestamp}ms. API Latency is ${Math.round(client.ping)}ms`);
  });
};
