exports.run = (client, message, args) => {

message.channel.send({embed: {
    color: 3447003,
    author: {
      name: client.user.username,
      icon_url: client.user.avatarURL
    },
    title: "Help",
    url: "",
    description: "All the commands in the traza bot",
    fields: [{
        name: "$help",
        value: "prints this command."
      },
      {
        name: "$kick",
        value: "kick command."
      },
      {
        name: "$play",
        value: "under construction."
      },
      {
        name: "$ping",
        value: "ping command."
      }
    ],
    timestamp: new Date(),
    footer: {
      icon_url: client.user.avatarURL,
      text: "© Poker1st"
    }
  }
});
}
