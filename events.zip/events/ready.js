exports.run = (client) => {
  console.log(`Logged in as ${client.user.tag} Serving in ` + client.guilds.array().length + " servers");
};
