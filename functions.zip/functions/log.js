module.exports = (type, message, title) => {
  if (!title) title = "Log";
  console.log(`[${type}] [${title}] ${message}`);
};
